<?php
return [
    'driver' => env('MAIL_DRIVER', 'sendgrid'),
];