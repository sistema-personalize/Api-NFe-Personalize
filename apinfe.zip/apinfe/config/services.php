<?php

return [
	'sendgrid' => [
        'api_key' => env('SENDGRID_API_KEY'),
    ],
];